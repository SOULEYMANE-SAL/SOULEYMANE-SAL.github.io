/* eslint-disable */
"use strict";

/**
 * Vérification des rappels SSV (server-side verification) d'AdMob
 * et règles de déblocage des contenus par vidéo récompensée.
 *
 * Règles métier :
 *  - 1 vidéo = 1 contenu précis, débloqué pendant 24 h ;
 *  - 3 vidéos maximum par jour et par utilisateur (jour calendaire UTC,
 *    = heure de Côte d'Ivoire) ;
 *  - au-delà → abonnement Éduc+.
 */

const crypto = require("crypto");

const VERIFIER_KEYS_URL = "https://www.gstatic.com/admob/reward/verifier-keys.json";
const UNLOCK_DURATION_MS = 24 * 60 * 60 * 1000;
const MAX_UNLOCKS_PER_DAY = 3;

/** Types de contenus déblocables et format attendu de custom_data. */
const CONTENT_KEY_PATTERN = /^(exam|chapter|quiz|book):[A-Za-z0-9_-]{1,128}$/;

class InvalidCallbackError extends Error {}

/** Le contenu signé = la chaîne de requête jusqu'à "&signature=" (exclu). */
function extractSignedContent(rawQuery) {
  const index = rawQuery.indexOf("&signature=");
  if (index === -1) {
    throw new InvalidCallbackError("Signature absente.");
  }
  return rawQuery.substring(0, index);
}

/**
 * Google signe la chaîne décodée (custom_data=exam:abc) mais l'envoie encodée
 * (exam%3Aabc). On teste la forme brute puis la forme décodée.
 */
function signedContentCandidates(signedContent) {
  let decoded;
  try {
    decoded = decodeURIComponent(signedContent);
  } catch (e) {
    return [signedContent];
  }
  return decoded === signedContent ? [signedContent] : [signedContent, decoded];
}

function base64UrlToBuffer(value) {
  const normalized = value.replace(/-/g, "+").replace(/_/g, "/");
  const padded = normalized + "=".repeat((4 - (normalized.length % 4)) % 4);
  return Buffer.from(padded, "base64");
}

/**
 * Vérifie la signature ECDSA (SHA-256) d'un rappel SSV.
 * @param {string} rawQuery chaîne de requête brute, telle que reçue
 * @param {Object<string,string>} keysById clés publiques PEM indexées par key_id
 */
function verifySignature(rawQuery, keysById) {
  const params = new URLSearchParams(rawQuery);
  const signature = params.get("signature");
  const keyId = params.get("key_id");
  if (!signature || !keyId) {
    throw new InvalidCallbackError("Signature ou key_id absent.");
  }
  const pem = keysById[keyId];
  if (!pem) {
    throw new InvalidCallbackError("Clé de vérification inconnue.");
  }
  const signatureBuffer = base64UrlToBuffer(signature);
  const signedContent = extractSignedContent(rawQuery);
  for (const candidate of signedContentCandidates(signedContent)) {
    const ok = crypto.verify("sha256", Buffer.from(candidate, "utf8"), pem, signatureBuffer);
    if (ok) {
      return params;
    }
  }
  throw new InvalidCallbackError("Signature invalide.");
}

/** Début du jour courant (UTC = heure de Côte d'Ivoire). */
function startOfDayUtc(now) {
  return new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth(), now.getUTCDate()));
}

/**
 * Lit les paramètres métier d'un rappel déjà authentifié.
 * Renvoie null si le rappel est signé mais inexploitable
 * (ex. requête de test envoyée par AdMob lors de l'enregistrement de l'URL).
 */
function parseRewardPayload(params) {
  const userId = params.get("user_id") || "";
  const contentKey = params.get("custom_data") || "";
  const transactionId = params.get("transaction_id") || "";
  if (!userId || !transactionId || !CONTENT_KEY_PATTERN.test(contentKey)) {
    return null;
  }
  if (!/^[A-Za-z0-9_-]{1,128}$/.test(userId) || !/^[A-Za-z0-9_-]{1,128}$/.test(transactionId)) {
    return null;
  }
  return { userId, contentKey, transactionId };
}

module.exports = {
  VERIFIER_KEYS_URL,
  UNLOCK_DURATION_MS,
  MAX_UNLOCKS_PER_DAY,
  CONTENT_KEY_PATTERN,
  InvalidCallbackError,
  extractSignedContent,
  signedContentCandidates,
  verifySignature,
  startOfDayUtc,
  parseRewardPayload,
};

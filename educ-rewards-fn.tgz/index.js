/* eslint-disable */
"use strict";

/**
 * Codebase "rewards" : vidéos récompensées AdMob.
 *
 * Déployé séparément des autres fonctions pour ne jamais les toucher :
 *   cd functions_rewards && npm install && firebase deploy --only functions:rewards
 *
 * URL à saisir dans AdMob (bloc récompensé → Vérification côté serveur) :
 *   https://us-central1-<PROJET>.cloudfunctions.net/admobRewardSsv
 */

const { onRequest } = require("firebase-functions/v2/https");
const logger = require("firebase-functions/logger");
const admin = require("firebase-admin");
const ssv = require("./ssv");

admin.initializeApp();
const db = admin.firestore();

const KEYS_CACHE_TTL_MS = 60 * 60 * 1000;
let cachedKeys = null;
let cachedKeysAt = 0;

/** Clés publiques AdMob, mises en cache 1 h (rechargées si key_id inconnu). */
async function fetchVerifierKeys(forceRefresh) {
  if (!forceRefresh && cachedKeys && Date.now() - cachedKeysAt < KEYS_CACHE_TTL_MS) {
    return cachedKeys;
  }
  const response = await fetch(ssv.VERIFIER_KEYS_URL);
  if (!response.ok) {
    throw new Error(`Clés AdMob indisponibles (HTTP ${response.status}).`);
  }
  const body = await response.json();
  const keysById = {};
  for (const key of body.keys || []) {
    keysById[String(key.keyId)] = key.pem;
  }
  cachedKeys = keysById;
  cachedKeysAt = Date.now();
  return keysById;
}

function rawQueryOf(req) {
  const url = req.originalUrl || req.url || "";
  const index = url.indexOf("?");
  return index === -1 ? "" : url.substring(index + 1);
}

/**
 * Enregistre le déblocage dans une transaction :
 * idempotent par transaction_id, plafonné à 3 par jour.
 * @return {Promise<{granted: boolean, reason?: string}>}
 */
async function grantUnlock({ userId, contentKey, transactionId }, now) {
  const userRef = db.collection("users").doc(userId);
  const grants = userRef.collection("rewardGrants");
  const grantRef = grants.doc(transactionId);
  const dayStart = ssv.startOfDayUtc(now);

  return db.runTransaction(async (tx) => {
    const existing = await tx.get(grantRef);
    if (existing.exists) {
      return { granted: true, reason: "déjà enregistré" };
    }
    const user = await tx.get(userRef);
    if (!user.exists) {
      return { granted: false, reason: "utilisateur inconnu" };
    }
    const today = await tx.get(
      grants.where("grantedAt", ">=", admin.firestore.Timestamp.fromDate(dayStart)),
    );
    if (today.size >= ssv.MAX_UNLOCKS_PER_DAY) {
      return { granted: false, reason: "limite quotidienne atteinte" };
    }
    tx.set(grantRef, {
      contentKey,
      grantedAt: admin.firestore.Timestamp.fromDate(now),
      expiresAt: admin.firestore.Timestamp.fromMillis(now.getTime() + ssv.UNLOCK_DURATION_MS),
      source: "admob_ssv",
    });
    return { granted: true };
  });
}

exports.admobRewardSsv = onRequest({ cors: false, maxInstances: 10 }, async (req, res) => {
  const rawQuery = rawQueryOf(req);
  let params;
  try {
    let keys = await fetchVerifierKeys(false);
    const keyId = new URLSearchParams(rawQuery).get("key_id");
    if (keyId && !keys[keyId]) {
      keys = await fetchVerifierKeys(true);
    }
    params = ssv.verifySignature(rawQuery, keys);
  } catch (error) {
    if (error instanceof ssv.InvalidCallbackError) {
      logger.warn("admob_ssv.rejected", { reason: error.message, rawQuery });
      res.status(400).json({ ok: false, message: error.message });
      return;
    }
    logger.error("admob_ssv.keys_error", { message: error.message });
    res.status(503).json({ ok: false, message: "Vérification indisponible." });
    return;
  }

  const payload = ssv.parseRewardPayload(params);
  if (!payload) {
    // Requête de test AdMob ou rappel inexploitable : signé, donc 200.
    logger.info("admob_ssv.ignored", { rawQuery });
    res.status(200).json({ ok: true, granted: false });
    return;
  }

  try {
    const result = await grantUnlock(payload, new Date());
    logger.info("admob_ssv.processed", { ...payload, ...result });
    res.status(200).json({ ok: true, ...result });
  } catch (error) {
    logger.error("admob_ssv.grant_error", { ...payload, message: error.message });
    res.status(500).json({ ok: false, message: "Erreur d'enregistrement." });
  }
});
